------------------------------------------------------------------Implementing gradient descent--------------------------------------------------------------------------


The code is developed in Java in Ubuntu 12.04 using Eclipse IDE.
The .java files have been uploaded in eLearning.

Perceptron.java has the "main()" method.

Copy the source files into Eclipse IDE and run the Perceptron.java file with the arguments. (Arguments: "Train file" "Test file" "learning rate" "iterations")
Arguments can be set in run configurations of Eclipse.

In order to run using command line, compile Attribute.java and Weights.java files and then compile-run the Perceptron.java file with the arguments.

-------------------------------------------------------------------------------Thank you---------------------------------------------------------------------------------


