import java.util.ArrayList;


public class Attribute {
	String name;
	int no_of_rows;
	 public void setrows(int rows){
		 no_of_rows = rows;
		 System.out.println("no_of_rows=" +rows);
	 }
	
	

}
